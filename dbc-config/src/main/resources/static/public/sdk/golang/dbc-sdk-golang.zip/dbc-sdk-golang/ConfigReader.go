package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"net/http"
	"strings"
	"time"
)

func randomKeyWithAES(length int) (string, error) {
	const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := range result {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(letters))))
		if err != nil {
			return "", err
		}
		result[i] = letters[num.Int64()]
	}
	return string(result), nil
}

func pkcs5Pad(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padtext...)
}

func pkcs5Unpad(src []byte, blockSize int) ([]byte, error) {
	length := len(src)
	padding := int(src[length-1])
	if padding > blockSize || padding == 0 {
		return nil, fmt.Errorf("invalid padding")
	}
	for i := length - 1; i > length-padding-1; i-- {
		if src[i] != byte(padding) {
			return nil, fmt.Errorf("invalid padding")
		}
	}
	return src[:length-padding], nil
}

func encryptAES(plaintext, key, iv []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	plaintext = pkcs5Pad(plaintext, aes.BlockSize)
	ciphertext := make([]byte, len(plaintext))
	stream := cipher.NewCBCEncrypter(block, iv)
	stream.CryptBlocks(ciphertext, plaintext)
	return ciphertext, nil
}

func decryptAES(ciphertext, key, iv []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	if len(ciphertext) < aes.BlockSize {
		return nil, fmt.Errorf("ciphertext too short")
	}
	stream := cipher.NewCBCDecrypter(block, iv)
	stream.CryptBlocks(ciphertext, ciphertext)
	return pkcs5Unpad(ciphertext, aes.BlockSize)
}

func encryptRSA(plaintext []byte, publicKey *rsa.PublicKey) ([]byte, error) {
	ciphertext, err := rsa.EncryptPKCS1v15(rand.Reader, publicKey, plaintext)
	if err != nil {
		return nil, err
	}
	return ciphertext, nil
}

func decryptRSA(ciphertext []byte, privateKey *rsa.PrivateKey) ([]byte, error) {
	plaintext, err := rsa.DecryptPKCS1v15(rand.Reader, privateKey, ciphertext)
	if err != nil {
		return nil, err
	}
	return plaintext, nil
}

func getPublicKey(client *http.Client, url, username, password string) (*rsa.PublicKey, error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.SetBasicAuth(username, password)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	var response map[string]interface{}
	err = json.Unmarshal(body, &response)
	if err != nil {
		return nil, err
	}
	publicKeyStr, ok := response["body"].(string)
	if !ok {
		return nil, fmt.Errorf("invalid response format")
	}
	fmt.Printf("\nPublic key string: \n%s\n", publicKeyStr)

	pemHeader := "-----BEGIN PUBLIC KEY-----\n"
	pemFooter := "\n-----END PUBLIC KEY-----"
	publicKeyPEM := pemHeader + publicKeyStr + pemFooter

	block, _ := pem.Decode([]byte(publicKeyPEM))
	if block == nil {
		return nil, fmt.Errorf("failed to parse PEM block containing the public key")
	}
	pub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	publicKey, ok := pub.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("public key is not of type *rsa.PublicKey")
	}
	return publicKey, nil
}

func main() {
	username := "user"
	password := "1"
	serviceName := "dbc-test"
	profileName := "dev"
	formats := "PROP"

	client := &http.Client{
		Timeout: 30 * time.Second,
	}

	publicKeyURL := "http://localhost:30170/h-dbc/api/publicKey"
	publicKey, err := getPublicKey(client, publicKeyURL, username, password)
	if err != nil {
		log.Fatalf("Failed to get public key: %v", err)
	}

	aesKey, err := randomKeyWithAES(16)
	if err != nil {
		log.Fatalf("Failed to generate AES key: %v", err)
	}
	aesIv, err := randomKeyWithAES(16)
	if err != nil {
		log.Fatalf("Failed to generate AES IV: %v", err)
	}
	fmt.Printf("\nkey: %s\n", aesKey)
	fmt.Printf("iv: %s\n", aesIv)

	aesKeyBytes := []byte(aesKey)
	aesIvBytes := []byte(aesIv)
	rsaKeyEncrypt, err := encryptRSA(aesKeyBytes, publicKey)
	if err != nil {
		log.Fatalf("Failed to encrypt AES key with RSA: %v", err)
	}
	rsaIvEncrypt, err := encryptRSA(aesIvBytes, publicKey)
	if err != nil {
		log.Fatalf("Failed to encrypt AES IV with RSA: %v", err)
	}
	rsaKeyEncryptBase64 := base64.StdEncoding.EncodeToString(rsaKeyEncrypt)
	rsaIvEncryptBase64 := base64.StdEncoding.EncodeToString(rsaIvEncrypt)

	app := map[string]string{
		"serviceName": serviceName,
		"profileName": profileName,
		"type":        formats,
	}
	appJSON, err := json.Marshal(app)
	if err != nil {
		log.Fatalf("Failed to marshal app JSON: %v", err)
	}

	aesKeyBytes = []byte(aesKey)
	aesIvBytes = []byte(aesIv)
	aesEncrypted, err := encryptAES(appJSON, aesKeyBytes, aesIvBytes)
	if err != nil {
		log.Fatalf("Failed to encrypt app JSON with AES: %v", err)
	}

	body := map[string]string{
		"key":  rsaKeyEncryptBase64,
		"iv":   rsaIvEncryptBase64,
		"body": base64.StdEncoding.EncodeToString(aesEncrypted),
	}
	bodyJSON, err := json.Marshal(body)
	if err != nil {
		log.Fatalf("Failed to marshal body JSON: %v", err)
	}

	fmt.Printf("\nPost body: \n%s\n", bodyJSON)

	configURL := "http://localhost:30170/h-dbc/api/config/list"
	req, err := http.NewRequest("POST", configURL, bytes.NewBuffer(bodyJSON))
	if err != nil {
		log.Fatalf("Failed to create request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.SetBasicAuth(username, password)
	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Failed to send request: %v", err)
	}
	defer resp.Body.Close()
	respBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalf("Failed to read response body: %v", err)
	}
	fmt.Printf("\nResponse data，before decrypt: \n%s\n", respBody)

	respBody = []byte(strings.Trim(string(respBody), `"`))

	ciphertext, err := base64.StdEncoding.DecodeString(string(respBody))
	if err != nil {
		log.Fatalf("Failed to decode Base64 response body: %v", err)
	}

	yamlBytes, err := decryptAES(ciphertext, aesKeyBytes, aesIvBytes)
	if err != nil {
		log.Fatalf("Failed to decrypt response data: %v", err)
	}
	yaml := string(yamlBytes)
	fmt.Printf("\nResponse data，after decrypt: \n%s\n", yaml)
}
