#include <iostream>
#include <string>
#include <sstream>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <nlohmann/json.hpp>
#include <random>
#include <algorithm>
#include <map>

using json = nlohmann::json;

std::string generateRandomAlnumString(size_t length) {
    const char alnum[] =
            "0123456789"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::string result;
    result.reserve(length);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, sizeof(alnum) - 2);

    for (size_t i = 0; i < length; ++i) {
        result += alnum[dis(gen)];
    }
    return result;
}

size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string getPublicKey(const std::string& user, const std::string& password) {
    std::cout << "Get PublicKey...\n" << std::endl;
    CURL* curl = curl_easy_init();
    std::string readBuffer;

    if (curl) {
        std::ostringstream oss;
        oss << "http://" << user << ":" << password << "@localhost:30170/h-dbc/api/publicKey";
        std::string url = oss.str();
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);

        if (curl_easy_perform(curl) != CURLE_OK) {
            std::cerr << "HTTP request failed" << std::endl;
        }
        curl_easy_cleanup(curl);
    }

    if (!readBuffer.empty())  {
        try {
            return json::parse(readBuffer)["body"];
        } catch (...) {
            return "";
        }
    }
    return "";
}

std::string randomKeyWithAES(int length) {
    std::string key(length, 0);
    RAND_bytes((unsigned char*)key.data(),  length);
    return key;
}

std::string base64Encode(const std::string& data) {
    BIO* bio = BIO_new(BIO_f_base64());
    BIO* mem = BIO_new(BIO_s_mem());
    bio = BIO_push(bio, mem);
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    BIO_write(bio, data.data(),  data.size());
    BIO_flush(bio);

    BUF_MEM* bufferPtr;
    BIO_get_mem_ptr(bio, &bufferPtr);
    std::string result(bufferPtr->data, bufferPtr->length);
    BIO_free_all(bio);
    return result;
}

int calcDecodeLength(const char* b64input) {
    int len = strlen(b64input);
    int padding = 0;
    if (b64input[len-1] == '=') padding++;
    if (b64input[len-2] == '=') padding++;
    return (len * 3) / 4 - padding;
}

std::string base64Decode(const std::string& data) {
    BIO* bio = BIO_new_mem_buf(data.c_str(), -1);
    BIO* b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);

    int decodeLen = calcDecodeLength(data.c_str());
    std::string result(decodeLen, 0);
    BIO_read(bio, result.data(),  decodeLen);
    BIO_free_all(bio);
    return result;
}

EVP_PKEY* createPublicKey(const std::string& publicKey) {
    // 自动补全PEM格式
    std::string formattedKey = publicKey;
    if (formattedKey.find("-----BEGIN  PUBLIC KEY-----") == std::string::npos) {
        formattedKey = "-----BEGIN PUBLIC KEY-----\n" + formattedKey;
    }
    if (formattedKey.find("-----END  PUBLIC KEY-----") == std::string::npos) {
        formattedKey += "\n-----END PUBLIC KEY-----";
    }

    BIO* keybio = BIO_new_mem_buf(formattedKey.c_str(), -1);
    if (!keybio) {
        std::cerr << "BIO memory assign failed" << std::endl;
        return nullptr;
    }

    EVP_PKEY* pkey = PEM_read_bio_PUBKEY(keybio, nullptr, nullptr, nullptr);
    if (!pkey) {
        ERR_print_errors_fp(stderr);
        std::cerr << "Corrected public key content：\n" << formattedKey << std::endl;
    }
    BIO_free(keybio);
    return pkey;
}

std::string rsaEncrypt(const std::string& data, EVP_PKEY* pkey) {
    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new(pkey, nullptr);
    if (!ctx || EVP_PKEY_encrypt_init(ctx) <= 0) return "";

    size_t outlen;
    if (EVP_PKEY_encrypt(ctx, nullptr, &outlen, (const unsigned char*)data.data(),  data.size())  <= 0) {
        EVP_PKEY_CTX_free(ctx);
        return "";
    }

    std::string encrypted(outlen, 0);
    if (EVP_PKEY_encrypt(ctx, (unsigned char*)encrypted.data(),  &outlen,
                         (const unsigned char*)data.data(),  data.size())  <= 0) {
        EVP_PKEY_CTX_free(ctx);
        return "";
    }

    EVP_PKEY_CTX_free(ctx);
    return base64Encode(encrypted);
}

std::string aesEncrypt(const std::string& data, const std::string& key, const std::string& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx || EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr,
                                   (const unsigned char*)key.data(),
                                   (const unsigned char*)iv.data())  != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return "";
    }

    int block_size = EVP_CIPHER_CTX_get_block_size(ctx);
    int outlen = data.size()  + block_size;
    std::string encrypted(outlen, 0);

    int len;
    EVP_EncryptUpdate(ctx, (unsigned char*)encrypted.data(),  &len,
                      (const unsigned char*)data.data(),  data.size());
    int final_len;
    EVP_EncryptFinal_ex(ctx, (unsigned char*)encrypted.data()  + len, &final_len);
    encrypted.resize(len  + final_len);
    EVP_CIPHER_CTX_free(ctx);
    return base64Encode(encrypted);
}

std::string aesDecrypt(const std::string& data, const std::string& key, const std::string& iv) {
    std::string decoded = base64Decode(data);
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx || EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr,
                                   (const unsigned char*)key.data(),
                                   (const unsigned char*)iv.data())  != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return "";
    }

    int block_size = EVP_CIPHER_CTX_get_block_size(ctx);
    int outlen = decoded.size()  + block_size;
    std::string decrypted(outlen, 0);

    int len;
    EVP_DecryptUpdate(ctx, (unsigned char*)decrypted.data(),  &len,
                      (const unsigned char*)decoded.data(),  decoded.size());
    int final_len;
    EVP_DecryptFinal_ex(ctx, (unsigned char*)decrypted.data()  + len, &final_len);
    decrypted.resize(len  + final_len);
    EVP_CIPHER_CTX_free(ctx);
    return decrypted;
}

int main() {

    std::string user = "user";
    std::string password = "1";
    std::string serviceName = "dbc-test";
    std::string profileName = "dev";
    std::string formats = "YAML";

    std::string publicKey = getPublicKey(user, password);
    if (publicKey.empty())  {
        std::cerr << "Error: The public key obtained is empty" << std::endl;
        return 1;
    } else {
        std::cout << "Get the public key: \n" << publicKey << "..." << std::endl;
    }

    std::string aesKey = generateRandomAlnumString(16);
    std::string aesIv = generateRandomAlnumString(16);
    // AES密钥生成后
    std::cout << "\nGenerate AES key: " << aesKey << std::endl;
    std::cout << "Generate AES IV: " << aesIv << std::endl;

    EVP_PKEY* pkey = createPublicKey(publicKey);
    if (!pkey) return 1;

    std::string rsaEncryptKey = rsaEncrypt(aesKey, pkey);
    std::string rsaEncryptIv = rsaEncrypt(aesIv, pkey);
    std::cout << "\nAfter AES key RSA encryption: " << rsaEncryptKey << std::endl;
    std::cout << "After AES IV RSA encryption: " << rsaEncryptIv << std::endl;

    std::map<std::string, std::string> request_map = {
            {"serviceName", serviceName},
            {"profileName", profileName},
            {"type", formats}
    };

    json request = request_map;
    std::string bodyEncrypt = aesEncrypt(request.dump(),  aesKey, aesIv);

    json payload = {
            {"key", rsaEncryptKey},
            {"iv", rsaEncryptIv},
            {"body", bodyEncrypt}
    };
    EVP_PKEY_free(pkey);

    CURL* curl = curl_easy_init();
    std::string response;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "http://user:1@localhost:30170/h-dbc/api/config/list");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.dump().c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

        struct curl_slist* headers = nullptr;
        headers = curl_slist_append(headers, "Content-Type: application/json; charset=utf-8");
        headers = curl_slist_append(headers, "Accept: application/json");

        std::string jsonPayload = payload.dump();
        std::cout << "\nJSON sent: \n" << jsonPayload << std::endl;

        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonPayload.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, jsonPayload.length());


        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_perform(curl);
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
    }

    if (!response.empty())  {
        std::cout << "\nResponse: \n" << response << std::endl;
        std::cout << "\nDecrypted: \n" << aesDecrypt(response, aesKey, aesIv) << std::endl;
    }
    return 0;
}