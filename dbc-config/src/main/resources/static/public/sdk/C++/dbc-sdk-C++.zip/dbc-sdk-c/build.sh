g++ -std=c++17 -Wall -Wextra \
    $(pkg-config --cflags openssl) \
    -I/opt/homebrew/Cellar/nlohmann-json/3.11.3/include \
    src/ConfigReader.cpp  \
    -o build/ConfigReader \
    $(pkg-config --libs openssl) \
    -lcurl