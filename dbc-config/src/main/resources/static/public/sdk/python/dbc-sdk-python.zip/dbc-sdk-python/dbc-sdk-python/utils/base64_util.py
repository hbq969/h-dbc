import base64

def encode(data):
    return base64.b64encode(data).decode('utf-8')

def decode(data):
    return base64.b64decode(data)
