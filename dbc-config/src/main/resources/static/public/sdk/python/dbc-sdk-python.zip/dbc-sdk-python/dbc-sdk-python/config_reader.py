import configparser
import requests
from utils.aes_utils import random_key_with_aes, encrypt, decrypt
from utils.base64_util import encode
from utils.rsa_util import encrypt as rsa_encrypt
import base64
import json

class ConfigReader:
    def __init__(self, config_file='config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        self.username = self.config['DEFAULT']['username']
        self.password = self.config['DEFAULT']['password']
        self.public_key_url = self.config['DEFAULT']['public_key_url']
        self.config_url = self.config['DEFAULT']['config_url']
        self.config_format = self.config['DEFAULT']['config_format']
        self.client = requests.Session()
        self.client.auth = (self.username, self.password)

    def get_public_key(self):
        response = self.client.get(self.public_key_url)
        response.raise_for_status()
        public_key = response.json()['body']
        public_key = f"-----BEGIN PUBLIC KEY-----\n{public_key}\n-----END PUBLIC KEY-----"
        return public_key

    def fetch_config(self, service_name, profile_name):
        public_key = self.get_public_key()
        print('\n从服务端获取rsa公钥: \n', public_key)
        aes_key = random_key_with_aes(16)
        aes_iv = random_key_with_aes(16)
        print('\n对称加密秘钥: %s \n对称加密iv: %s' % (aes_key, aes_iv))

        rsa_key_encrypt = rsa_encrypt(aes_key.encode('utf-8'), public_key)
        rsa_iv_encrypt = rsa_encrypt(aes_iv.encode('utf-8'), public_key)

        app = {
            "serviceName": service_name,
            "profileName": profile_name,
            "type": self.config_format
        }

        json_app = json.dumps(app, ensure_ascii=False, indent=None)

        body = {
            "key": rsa_key_encrypt,
            "iv": rsa_iv_encrypt,
            "body": encode(encrypt(json_app, aes_key.encode('utf-8'), aes_iv.encode('utf-8')))
        }

        # 使用 json.dumps 显式生成 JSON 字符串
        json_body = json.dumps(body, ensure_ascii=False, indent=None)
        print('\n拉取配置接口请求体: \n', json_body)

        headers = {
            'Content-Type': 'application/json'
        }

        response = self.client.post(self.config_url, data=json_body, headers=headers)

        response.raise_for_status()
        response_content = response.content
        print('\n拉取配置请求响应解密前报文: \n', response_content)  # 打印响应内容以调试

        # 解码 base64 编码的加密内容
        encrypted_bytes = base64.b64decode(response_content)

        # 解密内容
        decrypted_content = decrypt(encrypted_bytes, aes_key.encode('utf-8'), aes_iv.encode('utf-8'))
        print('\n拉取配置请求响应解密后报文: \n', decrypted_content)
        return decrypted_content

def main():
    config_reader = ConfigReader()
    config = config_reader.fetch_config('dbc-test', 'dev' )

if __name__ == "__main__":
    main()
