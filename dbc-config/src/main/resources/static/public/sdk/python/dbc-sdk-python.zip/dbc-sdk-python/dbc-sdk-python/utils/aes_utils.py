import os
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import secrets
import string


def random_key_with_aes(length=16):
    # 使用 secrets 模块生成一个 16 个字符长度的随机字符串
    characters = string.ascii_letters + string.digits
    random_string = ''.join(secrets.choice(characters) for _ in range(length))
    return random_string


def encrypt(data, key, iv, encoding='utf-8'):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(pad(data.encode(encoding), AES.block_size))


def decrypt(data, key, iv, encoding='utf-8'):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(data), AES.block_size).decode(encoding)
