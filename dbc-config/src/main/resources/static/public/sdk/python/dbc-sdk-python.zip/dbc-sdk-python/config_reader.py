import requests
import base64
import json
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import secrets
import string
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5

class ConfigReader:
    def __init__(self):
        self.username = "user"
        self.password = "1"
        self.service_name = "dbc-test"
        self.profile_name = "dev"
        self.public_key_url = "http://localhost:30170/h-dbc/api/publicKey"
        self.config_url = "http://localhost:30170/h-dbc/api/config/list"
        self.config_format = "PROP"
        self.client = requests.Session()
        self.client.auth = (self.username, self.password)

    def get_public_key(self):
        response = self.client.get(self.public_key_url)
        response.raise_for_status()
        public_key = response.json()['body']
        public_key = f"-----BEGIN PUBLIC KEY-----\n{public_key}\n-----END PUBLIC KEY-----"
        return public_key

    def random_key_with_aes(self, length=16):
        characters = string.ascii_letters + string.digits
        random_string = ''.join(secrets.choice(characters) for _ in range(length))
        return random_string

    def encrypt(self, data, key, iv, encoding='utf-8'):
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return cipher.encrypt(pad(data.encode(encoding), AES.block_size))

    def decrypt(self, data, key, iv, encoding='utf-8'):
        cipher = AES.new(key, AES.MODE_CBC, iv)
        return unpad(cipher.decrypt(data), AES.block_size).decode(encoding)

    def rsa_encrypt(self, data, public_key):
        key = RSA.import_key(public_key)
        cipher = PKCS1_v1_5.new(key)
        encrypted_data = cipher.encrypt(data)
        return base64.b64encode(encrypted_data).decode('utf-8')

    def encode(self, data):
        return base64.b64encode(data).decode('utf-8')

    def decode(self, data):
        return base64.b64decode(data)

    def fetch_config(self):
        public_key = self.get_public_key()
        print('\nGet the RSA public key from the server: \n', public_key)
        aes_key = self.random_key_with_aes(16)
        aes_iv = self.random_key_with_aes(16)
        print('\nAES encryption key: %s \nSymmetric encryption iv: %s' % (aes_key, aes_iv))

        rsa_key_encrypt = self.rsa_encrypt(aes_key.encode('utf-8'), public_key)
        rsa_iv_encrypt = self.rsa_encrypt(aes_iv.encode('utf-8'), public_key)

        app = {
            "serviceName": self.service_name,
            "profileName": self.profile_name,
            "type": self.config_format
        }

        json_app = json.dumps(app, ensure_ascii=False, indent=None)

        body = {
            "key": rsa_key_encrypt,
            "iv": rsa_iv_encrypt,
            "body": self.encode(self.encrypt(json_app, aes_key.encode('utf-8'), aes_iv.encode('utf-8')))
        }

        json_body = json.dumps(body, ensure_ascii=False, indent=None)
        print('\nPull configuration interface request body: \n', json_body)

        headers = {
            'Content-Type': 'application/json'
        }

        response = self.client.post(self.config_url, data=json_body, headers=headers)

        response.raise_for_status()
        response_content = response.content
        print('\nPull configuration request response before decryption: \n', response_content)

        encrypted_bytes = base64.b64decode(response_content)

        decrypted_content = self.decrypt(encrypted_bytes, aes_key.encode('utf-8'), aes_iv.encode('utf-8'))
        print('\nPull configuration request response decrypted message: \n', decrypted_content)
        return decrypted_content

def main():
    config_reader = ConfigReader()
    config = config_reader.fetch_config()

if __name__ == "__main__":
    main()
