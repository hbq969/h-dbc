const axios = require('axios');
const NodeRSA = require('node-rsa');
const CryptoJS = require('crypto-js');

class ConfigReader {
    async main() {
        const username = "user";
        const password = "1";

        // 1. 获取公钥
        const publicKeyUrl = "http://localhost:30170/h-dbc/api/publicKey";
        let publicKey;
        try {
            const response = await axios.get(publicKeyUrl, {
                auth: {
                    username: username,
                    password: password
                }
            });
            publicKey = response.data.body;
            console.log("\n公钥:", publicKey);
        } catch (error) {
            console.error("获取公钥失败:", error);
            return;
        }

        // 2. 生成AES秘钥和IV
        const aesKey = '2C278E7DF98946D3';
        const aesIv = '0CDE206E0CFB40A7';
        const keyEnc = CryptoJS.enc.Utf8.parse(aesKey);
        const ivEnc = CryptoJS.enc.Utf8.parse(aesIv);

        console.log('\naesKey: %s', aesKey)
        console.log('aesIv: %s', aesIv)

        // 3. 对AES秘钥和IV做RSA加密
        const jsEncrypt = new NodeRSA(publicKey, 'pkcs8-public');
        jsEncrypt.setOptions({encryptionScheme: 'pkcs1'})
        const rsaKeyEncrypt = jsEncrypt.encrypt(aesKey, 'base64');
        const rsaIvEncrypt = jsEncrypt.encrypt(aesIv, 'base64');

        // 4. 构建查询配置请求参数
        const app = {
            serviceName: "dbc-test",
            profileName: "dev",
            type: "PROP"
        };

        // 5. 构建请求参数
        const body = {
            key: rsaKeyEncrypt,
            iv: rsaIvEncrypt,
            body: this.encrypt(JSON.stringify(app), keyEnc, ivEnc)
        };

        console.log("\n请求报文:", JSON.stringify(body));

        // 6. 查询配置
        const configUrl = "http://localhost:30170/h-dbc/api/config/list";
        try {
            const response = await axios.post(configUrl, body, {
                headers: {
                    'Content-Type': 'application/json'
                },
                auth: {
                    username: username,
                    password: password
                }
            });
            const encryptedResponse = response.data;
            console.log("\n响应数据，解密前:", encryptedResponse);

            const decryptedResponse = this.decrypt(encryptedResponse, keyEnc, ivEnc);
            console.log("\n响应数据，解密后:", decryptedResponse);
        } catch (error) {
            console.error("查询配置失败:", error);
        }
    }

    //解密方法
    decrypt(word, key, iv) {

        var base64 = CryptoJS.enc.Base64.parse(word);

        var src = CryptoJS.enc.Base64.stringify(base64);

        // 解密模式为CBC，补码方式为PKCS5Padding（也就是PKCS7）
        var decrypt = CryptoJS.AES.decrypt(src, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });

        var decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
        return decryptedStr.toString();
    }

//加密方法
    encrypt(word, key, iv) {

        var srcs = CryptoJS.enc.Utf8.parse(word);
        // 加密模式为CBC，补码方式为PKCS5Padding（也就是PKCS7）
        var encrypted = CryptoJS.AES.encrypt(srcs, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });


        //返回base64
        return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
    }
}

// 执行main函数
const configReader = new ConfigReader();
configReader.main();
