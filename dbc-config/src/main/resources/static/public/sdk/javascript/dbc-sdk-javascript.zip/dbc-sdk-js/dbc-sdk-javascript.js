const axios = require('axios');
const NodeRSA = require('node-rsa');
const CryptoJS = require('crypto-js');

class ConfigReader {
    async main() {
        const username = 'user';
        const password = '1';
        const serviceName = 'dbc-test'
        const profileName = 'default'
        const formats = 'PROP'

        const publicKeyUrl = "http://localhost:30170/h-dbc/api/publicKey";
        let publicKey;
        try {
            const response = await axios.get(publicKeyUrl, {
                auth: {
                    username: username,
                    password: password
                }
            });
            publicKey = response.data.body;
            console.log("\nPublic Key:\n", publicKey);
        } catch (error) {
            console.error("Failed to obtain public key:", error);
            return;
        }

        const aesKey = this.generateRandomString(16);
        const aesIv = this.generateRandomString(16);
        const keyEnc = CryptoJS.enc.Utf8.parse(aesKey);
        const ivEnc = CryptoJS.enc.Utf8.parse(aesIv);

        console.log('\naesKey: %s', aesKey)
        console.log('aesIv: %s', aesIv)

        const jsEncrypt = new NodeRSA(publicKey, 'pkcs8-public');
        jsEncrypt.setOptions({encryptionScheme: 'pkcs1'})
        const rsaKeyEncrypt = jsEncrypt.encrypt(aesKey, 'base64');
        const rsaIvEncrypt = jsEncrypt.encrypt(aesIv, 'base64');

        const app = {
            serviceName: serviceName,
            profileName: profileName,
            type: formats
        };

        const body = {
            key: rsaKeyEncrypt,
            iv: rsaIvEncrypt,
            body: this.encrypt(JSON.stringify(app), keyEnc, ivEnc)
        };

        console.log("\nRequest message:\n", JSON.stringify(body));

        const configUrl = "http://localhost:30170/h-dbc/api/config/list";
        try {
            const response = await axios.post(configUrl, body, {
                headers: {
                    'Content-Type': 'application/json'
                },
                auth: {
                    username: username,
                    password: password
                }
            });
            const encryptedResponse = response.data;
            console.log("\nResponse data, before decryption:\n", encryptedResponse);

            const decryptedResponse = this.decrypt(encryptedResponse, keyEnc, ivEnc);
            console.log("\nResponse data, after decryption:\n", decryptedResponse);
        } catch (error) {
            console.error("Query configuration failed:", error);
        }
    }

    decrypt(word, key, iv) {
        var base64 = CryptoJS.enc.Base64.parse(word);
        var src = CryptoJS.enc.Base64.stringify(base64);
        var decrypt = CryptoJS.AES.decrypt(src, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        var decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
        return decryptedStr.toString();
    }

    encrypt(word, key, iv) {
        var srcs = CryptoJS.enc.Utf8.parse(word);
        var encrypted = CryptoJS.AES.encrypt(srcs, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
    }

    generateRandomString(length) {
        if (length < 1) return '';

        const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const DIGITS = '0123456789';
        let result = '';

        result += LETTERS[Math.floor(Math.random() * LETTERS.length)];

        const ALL_CHARS = LETTERS + DIGITS;
        for (let i = 1; i < length; i++) {
            result += ALL_CHARS[Math.floor(Math.random() * ALL_CHARS.length)];
        }

        return result;
    }
}

const configReader = new ConfigReader();
configReader.main();
